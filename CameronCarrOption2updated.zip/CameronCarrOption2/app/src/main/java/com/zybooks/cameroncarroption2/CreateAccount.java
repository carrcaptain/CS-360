package com.zybooks.cameroncarroption2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.apache.http.conn.ssl.AllowAllHostnameVerifier;

public class CreateAccount extends AppCompatActivity {
    EditText ActName, ActPhone, ActEmail, ActPswd, ActRePswd;
    Button SignUp, AllowTxt;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        AllowTxt = (Button) findViewById(R.id.AlwTxt);
        SignUp = (Button) findViewById(R.id.CreateActSubmitBtn);
        ActName = (EditText) findViewById(R.id.CreateName);
        ActPhone = (EditText) findViewById(R.id.editTextPhone);
        ActEmail = (EditText) findViewById(R.id.CreateActEml);
        ActPswd = (EditText) findViewById(R.id.CreatePswd);
        ActRePswd = (EditText) findViewById(R.id.ConfirmPswd);
        DB = new DBHelper(this);

        Button CreateActSubmitBtn = findViewById(R.id.CreateActSubmitBtn);

        CreateActSubmitBtn.setOnClickListener(new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                String actName = ActName.getText().toString();
                String actPhone = ActPhone.getText().toString();
                String actEmail = ActEmail.getText().toString();
                String actPswd = ActPswd.getText().toString();
                String actRePswd = ActRePswd.getText().toString();

                if((actName.equals(""))||(actEmail.equals(""))||(actPswd.equals(""))||(actRePswd.equals("")))
                    Toast.makeText(CreateAccount.this,"Please enter all the fields", Toast.LENGTH_SHORT).show();
                else {
                    if (actPswd.equals(actRePswd)) {
                        Boolean checkemail = DB.checkemail(actEmail);
                        if(checkemail==false){
                            Boolean insert = DB.insertData(actEmail,actPswd);
                            if(insert==true) {
                                Toast.makeText(CreateAccount.this,"Registered Successfully", Toast.LENGTH_SHORT).show();

                                Intent intent=new Intent(CreateAccount.this,MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(CreateAccount.this,"Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(CreateAccount.this,"User already exists. Please sign in.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(CreateAccount.this, "Passwords do not match. Please re-enter.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}