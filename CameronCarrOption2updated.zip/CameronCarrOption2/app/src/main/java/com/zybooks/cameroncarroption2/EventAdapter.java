package com.zybooks.cameroncarroption2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class EventAdapter extends ArrayAdapter {
    // initialization of even list array
    List list = new ArrayList();

    public EventAdapter(Context context, int resource) {
        super(context, resource);
    }

    static class LayoutHandler
    {
        // Layout of event list
        TextView NAME, DATE, TIME, LOCATION;
    }

    public void add(Object object) {
        super.add(object);
        list.add(object);
    }

    @Override
    public int getCount() {
        return list.size(); // count number of events added

    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    // display event list
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View row = convertView;
            LayoutHandler layoutHandler;
            if (row == null) { // ensure that row is not empty
                LayoutInflater layoutInflater = (LayoutInflater)this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                row = layoutInflater.inflate(R.layout.single_item,parent,false);
                layoutHandler = new LayoutHandler();
                layoutHandler.NAME = (TextView)row.findViewById(R.id.item_name);
                layoutHandler.DATE = (TextView)row.findViewById(R.id.item_Date);
                layoutHandler.TIME = (TextView)row.findViewById(R.id.item_time);
                layoutHandler.LOCATION = (TextView)row.findViewById(R.id.item_location);
                row.setTag(layoutHandler);
            } else {
                layoutHandler = (LayoutHandler)row.getTag();
            }

            Events events = (Events)this.getItem(position);
            layoutHandler.NAME.setText(events.getName());
            layoutHandler.DATE.setText(events.getDate());
            layoutHandler.TIME.setText(events.getTime());
            layoutHandler.LOCATION.setText(events.getLocation());

        return row;

    }
}
