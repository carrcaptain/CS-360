package com.zybooks.cameroncarroption2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class EventView extends AppCompatActivity {
    ListView listView;
    EventAdapter eventAdapter;
    DataBaseHelper myDb;
    SQLiteDatabase sqLiteDatabase;
    Button upDateBtn, AddEvntBtn, AllowTxt;
    ImageButton log_out;
    Cursor cursor;
    private int STORAGE_PERMISSION_CODE = 1;


    // screen creation for activity event view
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);

        myDb = new DataBaseHelper(getApplicationContext());
        sqLiteDatabase = myDb.getReadableDatabase();
        cursor = myDb.getAllData();
        eventAdapter = new EventAdapter(getApplicationContext(),R.layout.single_item);
        listView.setAdapter(eventAdapter);

        AddEvntBtn = (Button) findViewById(R.id.AddEventBtn); // link to add event button
        upDateBtn = (Button) findViewById(R.id.upDateBtn); // link to update button
        AllowTxt = (Button) findViewById(R.id.AlwTxt); // link to allow text button
        log_out = (ImageButton) findViewById(R.id.log_out); // link to log out button

        ActivityCompat.requestPermissions(EventView.this, new String[] {Manifest.permission.SEND_SMS}, PackageManager.PERMISSION_GRANTED);

        AddEvntBtn.setOnClickListener(new View.OnClickListener () {
            // method to be performed when add event button is clicked
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(EventView.this,AddEvent.class);
                startActivity(intent);
            }
        });

        AllowTxt.setOnClickListener(new View.OnClickListener () {
            // method to be performed when allow text button is clicked
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(EventView.this,
                        Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(EventView.this, "You have already granted this permission!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    requestStoragePermission();
                }
            }
        });

        log_out.setOnClickListener(new View.OnClickListener() {
            // method to be performed when log out button is clicked
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EventView.this, MainActivity.class);
                startActivity(intent);
            }
        });

        if (cursor.moveToFirst()) {


            do {
                String name, date, time, location;
                name=cursor.getString(0);
                date=cursor.getString(1);
                time=cursor.getString(2);
                location=cursor.getString(3);
                Events events = new Events(name, date, time, location);
                eventAdapter.add(events);
            }
                while(cursor.moveToFirst());

            }
        }



    private void requestStoragePermission() {
        // request permission for user to receive text messages
        if  (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("This permission is needed in order to receive text notifications")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(EventView.this, new String[] {Manifest.permission.SEND_SMS}, STORAGE_PERMISSION_CODE);

                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, STORAGE_PERMISSION_CODE);
        }
    }

    // confirm allowance of permission and send toast message to verify
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Not Granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}