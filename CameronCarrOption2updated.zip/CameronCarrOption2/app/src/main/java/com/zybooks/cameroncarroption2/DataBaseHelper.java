package com.zybooks.cameroncarroption2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    // layout of database table
    public static final String DATABASE_NAME = "events.db";
    public static final String TABLE_NAME = "EVENTS";
    public static final String Col_1 = "NAME";
    public static final String Col_2 = "DATE";
    public static final String Col_3 = "TIME";
    public static final String Col_4 = "LOCATION";

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME STRING, DATE INTEGER, TIME INTEGER, LOCATION STRING )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String Name, String Date, String TIME, String Location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Col_1,Name);
        contentValues.put(Col_2,Date);
        contentValues.put(Col_3,TIME);
        contentValues.put(Col_4,Location);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from " +TABLE_NAME, null);
        return result;
    }

    public boolean updateData(String id, String Name, String Date, String TIME, String Location ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Col_1,Name);
        contentValues.put(Col_2,Date);
        contentValues.put(Col_3,TIME);
        contentValues.put(Col_4,Location);
        db.update(TABLE_NAME, contentValues, "id = ?", new String[] { id });
        return true;
    }

    public Cursor viewData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from "+TABLE_NAME;
        Cursor result = db.rawQuery(query, null);

        return result;
    }
}
