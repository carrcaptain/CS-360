package com.zybooks.cameroncarroption2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.EventLog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEvent extends AppCompatActivity {
    DataBaseHelper myDb;
    EditText editEventName, editEventDate, editEventTime, editEventLocation;
    Button ConfirmEventBtn;
    Button ViewTableBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        myDb = new DataBaseHelper(this);

        editEventName = (EditText) findViewById(R.id.editEventName);
        editEventDate = (EditText) findViewById(R.id.editEventDate);
        editEventTime = (EditText) findViewById(R.id.editEventTime);
        editEventLocation = (EditText) findViewById(R.id.editEventLocation);
        ConfirmEventBtn = findViewById(R.id.ConfirmEventBtn);
        ViewTableBtn = findViewById(R.id.ViewTableBtn);
        viewAll();
        AddData();
    }

    public void AddData() {
        ConfirmEventBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(editEventName.getText().toString(),
                                editEventDate.getText().toString(),
                                editEventTime.getText().toString(),
                                editEventLocation.getText().toString());
                        if (isInserted = true)
                            Toast.makeText(AddEvent.this, "Events Updated", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    public void viewAll() {
        ViewTableBtn.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                            if (res.getCount() == 0) {
                                showMessage("Error","Nothing found");
                                return;
                            }

                            StringBuffer buffer = new StringBuffer();
                            while (res.moveToNext()) {
                                buffer.append("EVENT NAME : "+ res.getString(0)+"\n");
                                buffer.append("DATE : "+ res.getString(1)+"\n");
                                buffer.append("TIME : "+ res.getString(2)+"\n");
                                buffer.append("LOCATION : "+ res.getString(3)+"\n");
                            }

                            showMessage("Data",buffer.toString());
                    }
        }
        );
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

}