package com.zybooks.cameroncarroption2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button changeThemeBtn, CreateActBtn, LogIn;
    EditText Email, Pswd;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        changeThemeBtn = findViewById(R.id.switchTheme);
        CreateActBtn = findViewById(R.id.CreateActBtn);
        LogIn = findViewById(R.id.LogInBtn);
        Email = findViewById(R.id.EmailAddressTxt);
        Pswd = findViewById(R.id.PasswordTxt);
        DB = new DBHelper(this);


        LogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = Email.getText().toString();
                String password = Pswd.getText().toString();

                if(email.equals("")||password.equals(""))
                    Toast.makeText(MainActivity.this, "Please enter all fields.", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkemailpass = DB.checkemailpassword(email, password);
                    if(checkemailpass==true) {
                        Toast.makeText(MainActivity.this, "Sign in Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), EventView.class);
                        startActivity(intent);
                    }
                }
            }
        });

        CreateActBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,CreateAccount.class);
                startActivity(intent);
            }
        });

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            setTheme(R.style.DarkAppTheme);
        }

        changeThemeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                }

                finish();
                startActivity(new Intent(MainActivity.this, MainActivity.this.getClass()));
            }
        });


    }
}